#!/bin/sh
MainMenu()
{
while [ "$CHOICE" != "START" ]
do
clear
echo "================================================================="
echo "| SOCCER LEAGUE DATABASE UNIX MENUl|"
echo "| Main Menu - Select Desired Operation |"
echo "-----------------------------------------------------------------"
echo " $IS_SELECTED1 1) Drop Tables"
echo " $IS_SELECTED2 2) Create Tables"
echo " $IS_SELECTED3 3) Populate Tables"
echo " $IS_SELECTED4 4) Query Tables"
echo " $IS_SELECTED5 5) Simple Query Tables"
echo " "
echo " $IS_SELECTEDE E) End/Exit"
echo "Choose: "
read CHOICE
if [ "$CHOICE" == "0" ]
then
echo "Nothing Here"
elif [ "$CHOICE" == "1" ]
then
bash drop_tables.sh
read -p "Press [Enter] to continue..."
elif [ "$CHOICE" == "2" ]
then
bash create_tables.sh
read -p "Press [Enter] to continue..."
elif [ "$CHOICE" == "3" ]
then
bash populate_tables.sh
read -p "Press [Enter] to continue..."
elif [ "$CHOICE" == "4" ]
then
bash queries.sh
read -p "Press [Enter] to continue..."
elif [ "$CHOICE" == "5" ]
then
bash simplequeries.sh
read -p "Press [Enter] to continue..."
elif [ "$CHOICE" == "E" ]
then
exit
fi
done
}
#--COMMENTS BLOCK--
# Main Program
#--COMMENTS BLOCK--
ProgramStart()
{
StartMessage
while [ 1 ]
do
MainMenu
done
}
ProgramStart
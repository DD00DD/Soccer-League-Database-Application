#!/bin/sh
#export LD_LIBRARY_PATH=/usr/lib/oracle/12.1/client64/lib
sqlplus64 "ddao/05061838@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.scs.ryerson.ca)(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF

CREATE TABLE Leagues (
    league_id NUMBER PRIMARY KEY NOT NULL,
    league_name VARCHAR2(50) NOT NULL,
    number_of_teams NUMBER DEFAULT 0 CHECK(number_of_teams >= 0),
    total_seasons NUMBER DEFAULT 0 CHECK(total_seasons >= 0),
    average_player_rating NUMBER DEFAULT 1 CHECK(average_player_rating > 0 AND average_player_rating < 100),
    current_total_matches_played NUMBER DEFAULT 0 CHECK(current_total_matches_played >= 0)
);

CREATE TABLE Teams (
    team_id NUMBER PRIMARY KEY NOT NULL,
    team_name VARCHAR2(100) NOT NULL,
    city VARCHAR2(50) NOT NULL,
    country VARCHAR2(50) NOT NULL,
    team_mascot VARCHAR2(50) NOT NULL,
    year_founded DATE,
    wins NUMBER DEFAULT 0 CHECK(wins >= 0),
    draws NUMBER DEFAULT 0 CHECK(draws >= 0),
    losses NUMBER DEFAULT 0 CHECK(losses >= 0),
    goals_scored NUMBER DEFAULT 0 CHECK(goals_scored >= 0),
    goals_conceded NUMBER DEFAULT 0 CHECK(goals_conceded >= 0),
    stadium VARCHAR2(100) NOT NULL,
    league_id NUMBER,
    CONSTRAINT id_league_teams
        FOREIGN KEY (league_id) REFERENCES Leagues(league_id)
);

CREATE TABLE Soccer_Player (
    player_id NUMBER PRIMARY KEY NOT NULL,
    person_name VARCHAR2(100) NOT NULL,
    nationality VARCHAR2(50) NOT NULL,
    yellow_cards NUMBER DEFAULT 0 CHECK(yellow_cards >= 0),
    red_cards NUMBER DEFAULT 0 CHECK(red_cards >= 0),
    jersey_number NUMBER(3) NOT NULL CHECK(jersey_number > 0 AND jersey_number < 100),
    player_position VARCHAR2(50),
    rating NUMBER(3) DEFAULT 1 CHECK (rating > 0 AND rating < 100),
    matches_played NUMBER DEFAULT 0 CHECK(matches_played >= 0),
    goals NUMBER DEFAULT 0 CHECK(goals >= 0),
    assists NUMBER DEFAULT 0 CHECK(assists >= 0),
    injuries NUMBER DEFAULT 0 CHECK(injuries >= 0),
    league_id NUMBER,
    team_id NUMBER,
    CONSTRAINT id_league_soccer
        FOREIGN KEY (league_id) REFERENCES Leagues(league_id),
    CONSTRAINT id_team_soccer
        FOREIGN KEY (team_id) REFERENCES Teams(team_id)
);

CREATE TABLE Coaches (
    player_id NUMBER PRIMARY KEY NOT NULL,
    person_name VARCHAR2(100) NOT NULL,
    nationality VARCHAR2(50) NOT NULL,
    yellow_cards NUMBER DEFAULT 0 CHECK(yellow_cards >= 0),
    red_cards NUMBER DEFAULT 0 CHECK(red_cards >= 0),
    role VARCHAR2(100) NOT NULL,
    preferred_formation VARCHAR2(100) NOT NULL,
    years_of_experience NUMBER DEFAULT 0 CHECK(years_of_experience >= 0),
    league_id NUMBER,
    team_id NUMBER,
    CONSTRAINT id_league_coach
        FOREIGN KEY (league_id) REFERENCES Leagues(league_id),
    CONSTRAINT id_team_coach
        FOREIGN KEY (team_id) REFERENCES Teams(team_id)
);

CREATE TABLE Matches (
    match_id NUMBER PRIMARY KEY NOT NULL,
    season NUMBER DEFAULT 0 CHECK(season >= 0),
    match_date DATE,
    status VARCHAR2(50) NOT NULL,
    stadium VARCHAR2(100) NOT NULL,
    home_score NUMBER DEFAULT 0 CHECK(home_score >= 0),
    away_score NUMBER DEFAULT 0 CHECK(away_score >= 0),
    league_id NUMBER,
    home_team_id NUMBER NOT NULL,
    away_team_id NUMBER NOT NULL,
    CONSTRAINT id_league_match
        FOREIGN KEY (league_id) REFERENCES Leagues(league_id),
    CONSTRAINT fk_home_team
      FOREIGN KEY (home_team_id) REFERENCES Teams(team_id),
    CONSTRAINT fk_away_team
      FOREIGN KEY (away_team_id) REFERENCES Teams(team_id)
);


CREATE TABLE Rankings (
    rank_position NUMBER PRIMARY KEY NOT NULL,
    matches_played NUMBER DEFAULT 0 CHECK(matches_played >= 0),
    league_id NUMBER,
    team_id NUMBER,
    CONSTRAINT id_team_rank
        FOREIGN KEY (team_id) REFERENCES Teams(team_id),
    CONSTRAINT id_league_rank
        FOREIGN KEY (league_id) REFERENCES Leagues(league_id),
    points NUMBER DEFAULT 0 CHECK(points >= 0)
);


EXIT;
EOF
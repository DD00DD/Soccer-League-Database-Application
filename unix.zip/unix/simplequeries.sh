#!/bin/sh
sqlplus64 "ddao/05061838@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.cs.ryerson.ca)(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF

SELECT DISTINCT league_name FROM LEAGUES;
SELECT league_name, average_player_rating FROM LEAGUES ORDER BY average_player_rating DESC;
SELECT league_id, team_name, wins FROM Teams GROUP BY league_id, team_name,wins ORDER BY wins DESC;
SELECT * FROM Soccer_Player WHERE red_cards = 0;
SELECT DISTINCT player_position FROM Soccer_Player;
#!/bin/sh
sqlplus64 "ddao/05061838@(DESCRIPTION=(ADDRESS=(PROTOCOL=TCP)(Host=oracle.cs.ryerson.ca)(Port=1521))(CONNECT_DATA=(SID=orcl)))" <<EOF

SELECT * FROM TEAMS;


-- View that gets all the netherland players existing in soccer_player table and orders them by goals in descending order
CREATE VIEW Netherlands_Players AS
SELECT league_id, team_id, player_id, person_name, nationality, player_position, goals, assists
FROM Soccer_Player
WHERE nationality = 'Netherlands'
ORDER BY goals DESC;
SELECT * FROM Netherlands_Players; -- displays the netherlands_players view


-- view that gets all the matches that has been completed
CREATE VIEW Completed_Matches AS
SELECT league_id, match_id, match_date, status, stadium, home_score, home_team_id, away_score, away_team_id
FROM Matches
WHERE status = 'Completed';
SELECT * FROM Completed_Matches;


--- Shows head coaches with more than five years of experience.
CREATE VIEW Experienced_Head_Coach AS
SELECT PERSON_NAME, YEARS_OF_EXPERIENCE
FROM COACHES
WHERE YEARS_OF_EXPERIENCE > 5 AND ROLE = 'Head Coach';
SELECT * FROM Experienced_Head_Coach;
